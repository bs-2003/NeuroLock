<?php
define('ADMIN_USUARIO', 'kayser');
define('ADMIN_PASSWORD', '123456rlz');

?>